#include "texCoords.h"

TexCoords::TexCoords() {
    u = 0;
    v = 0;
}

TexCoords::TexCoords(float u, float v) {
    this->u = u;
    this->v = v;
}